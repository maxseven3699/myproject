insert into admin(username, password) values ('sutthiporn', '1234');
insert into admin(username, password) values ('sutthiporn1', '1234');
insert into admin(username, password) values ('sutthiporn2', '1234');
insert into admin(username, password) values ('sutthiporn3', '1234');
insert into admin(username, password) values ('sutthiporn4', '1234');


insert into users(username, password, repassword, answer, address, tel, fax, email) values ('sutthiporn5', '1234', '1234', 'maxmax', '42/7', '035123456', '035123456', 'melody-za3699@hotmaail.com');
insert into users(username, password, repassword, answer, address, tel, fax, email) values ('sutthiporn6', '1234', '1234', 'maxky', '42/8', '035123457', '035123457', 'melody-za3690@hotmaail.com');
insert into users(username, password, repassword, answer, address, tel, fax, email) values ('sutthiporn7', '1234', '1234', 'maxy', '42/9', '035123458', '035123458', 'melody-za3691@hotmaail.com');
insert into users(username, password, repassword, answer, address, tel, fax, email) values ('sutthiporn8', '1234', '1234', 'maxka', '42/10', '035123459', '035123459', 'melody-za3692@hotmaail.com');
insert into users(username, password, repassword, answer, address, tel, fax, email) values ('sutthiporn9', '1234', '1234', 'maxka1', '42/11', '035123450', '035123450', 'melody-za3693@hotmaail.com');