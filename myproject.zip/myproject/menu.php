<?php
echo "<h2>Welcome to Myproject (Sutthiporn Suthamma)</h2>";
echo " <hr>
 | <a href = 'index.php'>     Home         </a>
 | <a href = 'aboutus.php'>   About Us     </a>
 | <a href = 'myproject.php'> My Project   </a>
 | <a href = 'mycode.php'>    My Code      </a>
 | <a href = 'contactus.php'> Contact Us | </a>
<hr> ";
?>
