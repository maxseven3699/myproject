<?PHP
$num1 = 50;
$num2 = 20;
$sum = $num1+$num2;
$name = "Sutthiporn Suthamma";
$position = "Web programmer";
$salary = 9000;
$bonus = $salary*20/100 ;
//แสดงผล
echo "$num1+$num2 = $sum";
echo "<br>ชื่อ ".$name;
echo "<br>ตำแหน่ง ".$position;
echo "<br>เงินเดือน ".$salary;
echo "<br>โบนัส ".$bonus;
?>
