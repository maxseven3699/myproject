<?php
echo "PHP Hello world <br>";
echo "Mr.Sutthiporn Suthamma <br>";
echo "i am web programmer <br> <hr>";
?>
