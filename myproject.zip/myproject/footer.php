<?php
// <dir align ='center'>คำสั่งจัดกึ่งกลางหรือซ้ายขวา//
// '' ใช้ใส่ในคำสั่ง "" ใช้ใส่ในการโชว์จะได้ไม่ีตีกันถ้าใส่เหมือนกันจะ Eror//
echo "
<div align='center'>
<br>Coppyright&copy2017; by Sutthiporn.com All Right Reserved
</div>";
?>
