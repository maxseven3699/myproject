<hr>
<pre>
<b>BIT NEWS</b>

✔<a href = 'n1.php'><b> Apple ไตรมาสล่าสุด รายได้รวมกลับมาเติบโตอีกครั้ง, iPhone ขายได้ 78.29 ล้านเครื่อง</b></a>

✔<a href = 'n2.php'><b>กูเกิลเปิดซอร์ส Chrome for iOS นำโค้ดขึ้นโครงการ Chromium</b></a>

✔<a href = 'n3.php'><b>รู้จัก YO เครื่องนับจำนวนอสุจิ ใช้งานผ่านสมาร์ทโฟน</b></a>

✔<a href = 'n4.php'><b>สั่งกาแฟ Starbucks ด้วยเสียงได้ผ่าน Amazon Alexa และแอพ Starbucks ในระบบ iOS</b></a>


</pre>
