<pre>
<b>เข้าสู่ระบบ</b>
<form method= "post"Action="login2.php">
  Username : <input type="text" Name="username">

  Password  : <input type="password" Name="password">

                    <input type="submit" value="เข้าระบบ">
            </form>
</pre>
