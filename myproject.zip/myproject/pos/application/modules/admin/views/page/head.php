<title><?php echo $title ?></title>
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/font-awesome/css/font-awesome.min.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/bootstrap/css/bootstrap.min.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/uniform/css/uniform.default.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/jqvmap/jqvmap/jqvmap.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/select2/select2.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/bootstrap-toastr/toastr.min.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/summernote/summernote.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/components.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/plugins.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/layout.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/themes/red-sunglo.css") ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/local.css") ?>">