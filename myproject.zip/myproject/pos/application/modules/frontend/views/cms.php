<div class="row products">
	<div class="col-md-12">
		<?php echo $content; ?>
	</div>
</div>
